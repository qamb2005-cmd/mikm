/**
 * MikroTik REST API Wrapper
 * Requirements: RouterOS v7+
 * Uses server.py as a proxy to bypass CORS
 */
const MikroTikAPI = {
    // Current router configuration
    config: {
        host: localStorage.getItem('mk_host') || '',
        username: localStorage.getItem('mk_user') || '',
        password: localStorage.getItem('mk_pass') || '',
        useSSL: true
    },

    async request(path, method = 'GET', body = null) {
        if (!this.config.host || !this.config.username) {
            throw new Error("MikroTik sozlamalari kiritilmagan!");
        }

        const targetUrl = `https://${this.config.host}/rest/${path}`;
        const auth = btoa(`${this.config.username}:${this.config.password}`);

        try {
            // Priority: 1. Manual Server IP (local), 2. Default relative path (Netlify/Domain)
            const serverIp = localStorage.getItem('server_ip');
            // If we are on localhost but want to target a specific remote server
            let proxyBase = serverIp ? `http://${serverIp}:8080` : '';

            // If we are already on a production domain (not localhost), always use relative paths
            if (window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') {
                proxyBase = '';
            }

            const response = await fetch(`${proxyBase}/api-proxy`, {
                method: 'POST',
                headers: {
                    'X-Target-URL': targetUrl,
                    'Authorization': `Basic ${auth}`,
                    'Content-Type': 'application/json'
                },
                body: body ? JSON.stringify(body) : null
            });

            if (!response.ok) {
                const errorData = await response.text();
                throw new Error(errorData || `API Xatolik: ${response.status}`);
            }
            return await response.json();
        } catch (error) {
            console.error('MikroTik API Xatosi:', error);
            throw error;
        }
    },

    // User Manager Methods
    async getUsers() {
        return this.request('user-manager/user');
    },

    async createUser(userData) {
        return this.request('user-manager/user', 'POST', userData);
    },

    async deleteUser(userName) {
        const users = await this.getUsers();
        const user = users.find(u => u.name === userName);
        if (user && user['.id']) {
            return this.request(`user-manager/user/${user['.id']}`, 'DELETE');
        }
    },

    async getProfiles() {
        return this.request('user-manager/profile');
    },

    // Logs & Health
    async getSessions() {
        return this.request('user-manager/session');
    },

    async getPayments() {
        return this.request('user-manager/payment');
    },

    async deleteSession(sessionId) {
        if (!sessionId) return;
        return this.request(`user-manager/session/${sessionId}`, 'DELETE');
    },

    async testConnection() {
        return this.request('system/resource');
    },

    async getSystemResources() {
        return this.request('system/resource');
    },

    async getSystemHealth() {
        try {
            return await this.request('system/health');
        } catch (e) {
            return []; // Health might not be supported on all models
        }
    },

    async getInterfaces() {
        return this.request('interface');
    },

    async getSystemIdentity() {
        return this.request('system/identity');
    },

    async ping(address) {
        // RouterOS REST API for ping: /tool/ping with POST body
        return this.request('tool/ping', 'POST', { address: address, count: 4 });
    },

    // Save config and update instance
    saveConfig(host, user, pass) {
        this.config.host = host;
        this.config.username = user;
        this.config.password = pass;
        localStorage.setItem('mk_host', host);
        localStorage.setItem('mk_user', user);
        localStorage.setItem('mk_pass', pass);
    }
};
