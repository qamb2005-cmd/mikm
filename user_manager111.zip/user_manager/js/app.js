document.addEventListener('DOMContentLoaded', () => {
    const navItems = document.querySelectorAll('.nav-item');
    const viewContainer = document.getElementById('view-container');
    const loginScreen = document.getElementById('login-screen');
    const app = document.getElementById('app');
    const themeToggle = document.getElementById('theme-toggle');
    const langBtns = document.querySelectorAll('.lang-btn');
    const menuToggle = document.getElementById('menu-toggle');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebar-overlay');

    // Mobile Menu Logic
    if (menuToggle) {
        menuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('active');
            sidebarOverlay.classList.toggle('active');
        });
    }

    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', () => {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        });
    }

    // i18n Translations
    const translations = {
        uz: {
            app_name: "MikroTik",
            welcome_text: "Boshqaruv paneliga xush kelibsiz",
            login: "Login",
            password: "Parol",
            enter_login: "Loginni kiriting",
            enter_password: "Parolni kiriting",
            login_btn: "Kirish",
            login_error_msg: "Login yoki parol noto'g'ri!",
            nav_dashboard: "🏠 Dashboard",
            nav_users: "👥 Mijozlar",
            nav_vouchers: "🎫 Vaucherlar",
            nav_sessions: "📶 Sessiyalar",
            nav_sales: "💵 Sotuvlar",
            nav_settings: "⚙️ Sozlamalar",
            nav_logout: "🚪 Chiqish",
            search_placeholder: "Qidiruv...",
            profile: "Profil",
            router_online: "Online",
            router_offline: "Offline / Xatolik",
            router_connecting: "Ulanmoqda...",
            dash_sold_today: "💰 Bugun Sotildi",
            dash_total_users: "👥 Jami Foydalanuvchilar",
            dash_vouchers: "🎫 Vaucherlar",
            dash_router_status: "📡 Router Holati",
            dash_cpu: "💻 CPU Yuklamasi",
            dash_ram: "🧠 RAM (Xotira)",
            dash_storage: "💾 Disk (HDD)",
            dash_uptime: "⏱️ Ishlash Vaqti",
            dash_temp: "🌡️ Harorat",
            dash_speed: "🚀 Tarmoq Tezligi",
            dash_up: "Yuborish (UP)",
            dash_down: "Qabul (DOWN)",
            dash_growth: "o'sish",
            dash_ready: "Sotuvga tayyor",
            dash_quick_actions: "Tezkor Amallar",
            dash_create_voucher: "Vaucher Yaratish",
            dash_create_voucher_desc: "Yangi vaucherlar to'plamini generatsiya qilish.",
            vouchers_title: "🎁 Vaucherlar",
            vouchers_new: "✨ Yangi Vaucherlar",
            vouchers_create_card: "Vaucher Yaratish",
            vouchers_create_desc: "Yangi vaucherlar to'plamini yarating",
            users_title: "👥 Mijozlar",
            users_new_btn: "👤 Foydalanuvchi Qo'shish",
            users_new_card: "Yangi Mijoz",
            users_new_desc: "Routerga yangi foydalanuvchi qo'shish",
            btn_delete: "O'chirish",
            btn_edit: "Tahrirlash",
            btn_print: "Chop etish",
            confirm_delete: "ni o'chirib tashlamoqchimisiz?",
            modal_add_voucher: "Vaucher Generatsiya",
            modal_add_user: "Yangi foydalanuvchi",
            form_profile: "Profilni tanlang",
            form_prefix: "Vaucher prefiksi",
            form_price: "Sotuv narxi (UZS)",
            form_count: "Miqdor (nechta vaucher)",
            form_creating: "Yaratilmoqda...",
            form_cancel: "Bekor qilish",
            form_generate: "Generatsiya qilish",
            form_add: "Qo'shish",
            form_login_label: "Foydalanuvchi nomi (Login)",
            form_pass_label: "Parol (ixtiyoriy)",
            settings_admin: "Admin Profili",
            settings_change: "O'zgartirish",
            settings_success: "Muvaffaqiyatli saqlandi!",
            settings_router: "MikroTik Router Sozlamalari",
            settings_test: "Ulanishni tekshirish"
        },
        ru: {
            app_name: "MikroTik",
            welcome_text: "Добро пожаловать в панель управления",
            login: "Логин",
            password: "Пароль",
            enter_login: "Введите логин",
            enter_password: "Введите пароль",
            login_btn: "Войти",
            login_error_msg: "Неверный логин или пароль!",
            nav_dashboard: "🏠 Панель",
            nav_users: "👥 Клиенты",
            nav_vouchers: "🎫 Ваучеры",
            nav_sessions: "📶 Сессии",
            nav_sales: "💵 Продажи",
            nav_settings: "⚙️ Настройки",
            nav_logout: "🚪 Выход",
            search_placeholder: "Поиск...",
            profile: "Профиль",
            router_online: "Онлайн",
            router_offline: "Оффлайн / Ошибка",
            router_connecting: "Подключение...",
            dash_sold_today: "💰 Продано Сегодня",
            dash_total_users: "👥 Всего Пользователей",
            dash_vouchers: "🎫 Ваучеры",
            dash_router_status: "📡 Статус Роутера",
            dash_cpu: "💻 Загрузка CPU",
            dash_ram: "🧠 ОЗУ (Память)",
            dash_storage: "💾 Диск (HDD)",
            dash_uptime: "⏱️ Время работы",
            dash_temp: "🌡️ Температура",
            dash_speed: "🚀 Скорость сети",
            dash_up: "Yuklash (UP)",
            dash_down: "Ko'chirish (DOWN)",
            dash_growth: "рост",
            dash_ready: "Готовы к продаже",
            dash_quick_actions: "Быстрые Действия",
            dash_create_voucher: "Создать Ваучер",
            dash_create_voucher_desc: "Генерация нового пакета ваучеров.",
            vouchers_title: "🎁 Ваучеры",
            vouchers_new: "✨ Новый Ваучер",
            vouchers_create_card: "Создать Ваучер",
            vouchers_create_desc: "Создать новый пакет ваучеров",
            users_title: "👥 Клиенты",
            users_new_btn: "👤 Добавить Пользователя",
            users_new_card: "Новый Клиент",
            users_new_desc: "Добавить пользователя в роутер",
            btn_delete: "Удалить",
            btn_edit: "Изменить",
            btn_print: "Печать",
            confirm_delete: "вы уверены, что хотите удалить?",
            modal_add_voucher: "Генерация Ваучеров",
            modal_add_user: "Новый пользователь",
            form_profile: "Выберите профиль",
            form_prefix: "Префикс ваучера",
            form_price: "Цена продажи (UZS)",
            form_count: "Количество",
            form_creating: "Создание...",
            form_cancel: "Отмена",
            form_generate: "Генерировать",
            form_add: "Добавить",
            form_login_label: "Имя пользователя (Логин)",
            form_pass_label: "Пароль (опционально)",
            settings_admin: "Профиль Админа",
            settings_change: "Изменить",
            settings_success: "Успешно сохранено!",
            settings_router: "Настройки Роутера MikroTik",
            settings_test: "Проверить соединение"
        },
        en: {
            app_name: "MikroTik",
            welcome_text: "Welcome to dashboard",
            login: "Login",
            password: "Password",
            enter_login: "Enter login",
            enter_password: "Enter password",
            login_btn: "Login",
            login_error_msg: "Invalid login or password!",
            nav_dashboard: "🏠 Dashboard",
            nav_users: "👥 Clients",
            nav_vouchers: "🎫 Vouchers",
            nav_sessions: "📶 Sessions",
            nav_sales: "💵 Sales",
            nav_settings: "⚙️ Settings",
            nav_logout: "🚪 Logout",
            search_placeholder: "Search...",
            profile: "Profile",
            router_online: "Online",
            router_offline: "Offline / Error",
            router_connecting: "Connecting...",
            dash_sold_today: "💰 Sold Today",
            dash_total_users: "👥 Total Users",
            dash_vouchers: "🎫 Vouchers",
            dash_router_status: "📡 Router Status",
            dash_cpu: "💻 CPU Load",
            dash_ram: "🧠 RAM Memory",
            dash_storage: "💾 Disk Storage",
            dash_uptime: "⏱️ System Uptime",
            dash_temp: "🌡️ Temperature",
            dash_speed: "🚀 Network Speed",
            dash_up: "Upload",
            dash_down: "Download",
            dash_growth: "growth",
            dash_ready: "Ready for sale",
            dash_quick_actions: "Quick Actions",
            dash_create_voucher: "Create Voucher",
            dash_create_voucher_desc: "Generate a new batch of vouchers.",
            vouchers_title: "🎁 Vouchers",
            vouchers_new: "✨ New Vouchers",
            vouchers_create_card: "Create Voucher",
            vouchers_create_desc: "Create a new set of vouchers",
            users_title: "👥 Clients",
            users_new_btn: "👤 Add User",
            users_new_card: "New Client",
            users_new_desc: "Add new user to router",
            btn_delete: "Delete",
            btn_edit: "Edit",
            btn_print: "Print",
            confirm_delete: "are you sure you want to delete?",
            modal_add_voucher: "Voucher Generation",
            modal_add_user: "New User",
            form_profile: "Select profile",
            form_prefix: "Voucher prefix",
            form_price: "Sale price (UZS)",
            form_count: "Quantity",
            form_creating: "Creating...",
            form_cancel: "Cancel",
            form_generate: "Generate",
            form_add: "Add",
            form_login_label: "Username (Login)",
            form_pass_label: "Password (optional)",
            settings_admin: "Admin Profile",
            settings_change: "Change",
            settings_success: "Successfully saved!",
            settings_router: "MikroTik Router Settings",
            settings_test: "Test Connection"
        }
    };

    // Simple State
    const state = {
        lang: localStorage.getItem('lang') || 'uz',
        currentView: 'dashboard',
        users: [],
        profiles: [],
        vouchers: [],
        sessions: [],
        payments: [],
        demoMode: false,
        sales: { today: 0, growth: 0 },
        theme: localStorage.getItem('theme') || 'light',
        auth: {
            username: '',
            password: '',
            role: 'admin',
            isLoggedIn: sessionStorage.getItem('isLoggedIn') === 'true'
        },
        mikrotik: {
            host: localStorage.getItem('mk_host') || '',
            user: localStorage.getItem('mk_user') || '',
            pass: localStorage.getItem('mk_pass') || '',
            status: 'offline',
            identity: 'MikroTik',
            resources: null,
            health: null,
            interfaces: [],
            traffic: { prevTx: 0, prevRx: 0, txSpeed: 0, rxSpeed: 0, lastCheck: 0 }
        },
        routers: JSON.parse(localStorage.getItem('mk_routers') || '[]'),
        currentRouterName: localStorage.getItem('mk_router_active') || ''
    };

    function t(key) {
        return translations[state.lang][key] || key;
    }

    function updateLanguage() {
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            el.innerHTML = t(key);
        });
        document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
            const key = el.getAttribute('data-i18n-placeholder');
            el.placeholder = t(key);
        });
        document.querySelectorAll('[data-i18n-title]').forEach(el => {
            const key = el.getAttribute('data-i18n-title');
            el.title = t(key);
        });

        // Highlight active lang button
        langBtns.forEach(btn => {
            if (btn.getAttribute('data-lang') === state.lang) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
    }

    // Language Change Logic
    langBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const lang = btn.getAttribute('data-lang');
            state.lang = lang;
            localStorage.setItem('lang', state.lang);
            updateLanguage();
            // Re-render current view to update dynamic content
            if (state.auth.isLoggedIn) {
                switchView(state.currentView);
            }
        });
    });

    // Apply Language
    updateLanguage();

    // Apply Theme
    document.documentElement.setAttribute('data-theme', state.theme);

    function applyRoleRestrictions() {
        const role = state.auth.role || 'admin';
        const settingsNav = document.querySelector('[data-view="settings"]');
        if (settingsNav) {
            settingsNav.style.display = role === 'viewer' ? 'none' : '';
        }

        // Hide destructive actions for viewer
        if (role === 'viewer') {
            document.querySelectorAll('.btn-danger, .btn-delete').forEach(btn => {
                btn.disabled = true;
            });
        }
    }

    // Initial Auth Check
    if (state.auth.isLoggedIn) {
        showApp();
    }

    // Login logic (Server-side via Netlify Function)
    document.getElementById('login-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const u = document.getElementById('login-username').value;
        const p = document.getElementById('login-password').value;
        const submitBtn = e.target.querySelector('button[type="submit"]');
        const errorEl = document.getElementById('login-error');

        submitBtn.disabled = true;
        errorEl.style.display = 'none';

        try {
            const resp = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username: u, password: p })
            });

            const data = await resp.json();

            if (resp.ok && data.status === 'success') {
                sessionStorage.setItem('isLoggedIn', 'true');
                state.auth.username = u;
                state.auth.isLoggedIn = true;
                showApp();
            } else {
                errorEl.innerText = data.message || t("login_error_msg");
                errorEl.style.display = 'block';
            }
        } catch (err) {
            errorEl.innerText = "Server bilan aloqa uzildi. Internetni tekshiring.";
            errorEl.style.display = 'block';
        } finally {
            submitBtn.disabled = false;
        }
    });

    async function showApp() {
        loginScreen.style.display = 'none';
        app.classList.add('authenticated');
        switchView('dashboard');
        applyRoleRestrictions();

        // Connect to MikroTik
        if (state.mikrotik.host) {
            testMikroTikConnection();
        }
    }

    async function testMikroTikConnection() {
        const statusEl = document.querySelector('.router-status');
        if (statusEl) {
            statusEl.innerText = t("router_connecting");
            statusEl.className = "router-status";
        }

        try {
            await MikroTikAPI.testConnection();
            state.mikrotik.status = 'online';

            try {
                const identity = await MikroTikAPI.getSystemIdentity();
                state.mikrotik.identity = identity.name || identity[0]?.name || 'MikroTik';
            } catch (e) { console.warn("Identity fetch failed", e); }

            if (statusEl) {
                statusEl.innerHTML = `${state.mikrotik.identity} ${t("router_online")}`;
                statusEl.className = "router-status online";
            }
            loadData();
        } catch (e) {
            state.mikrotik.status = 'offline';
            if (statusEl) {
                statusEl.innerText = t("router_offline");
                statusEl.className = "router-status";
                statusEl.style.background = "var(--danger)";
                statusEl.style.color = "white";
            }
        }
    }

    async function loadData() {
        try {
            const users = await MikroTikAPI.getUsers();
            state.users = users || [];
            if (state.currentView === 'users') renderUsers();

            // Robust data fetching
            try {
                const profiles = await MikroTikAPI.getProfiles();
                state.profiles = profiles || [];
            } catch (e) { console.warn("Failed to fetch profiles", e); }

            try {
                const resources = await MikroTikAPI.getSystemResources();
                state.mikrotik.resources = resources[0] || resources;
            } catch (e) { console.warn("Failed to fetch resources", e); }

            try {
                const health = await MikroTikAPI.getSystemHealth();
                state.mikrotik.health = health;
            } catch (e) { console.warn("Failed to fetch health", e); }

            try {
                const interfaces = await MikroTikAPI.getInterfaces();
                state.mikrotik.interfaces = interfaces;
                calculateSpeed(interfaces);
            } catch (e) { console.warn("Failed to fetch interfaces", e); }

            // Sessions
            try {
                const sessions = await MikroTikAPI.getSessions();
                state.sessions = sessions || [];
            } catch (e) { console.warn("Failed to fetch sessions", e); }

            // Payments / Sales
            try {
                const payments = await MikroTikAPI.getPayments();
                const now = new Date();
                const todayStr = now.toISOString().split('T')[0]; // YYYY-MM-DD

                let todaySales = 0;
                (payments || []).forEach(p => {
                    // MikroTik date can be like "mar/03/2024" or "2024-03-03 12:00:00"
                    // We'll try to match the ISO date part
                    if (p.time && p.time.includes(todayStr)) {
                        todaySales += parseFloat(p.amount || 0);
                    } else if (p.time) {
                        // Fallback for different MikroTik formats
                        const pDate = new Date(p.time.replace(/-/g, '/'));
                        if (pDate.toDateString() === now.toDateString()) {
                            todaySales += parseFloat(p.amount || 0);
                        }
                    }
                });
                state.sales.today = todaySales;
                state.payments = payments || [];
            } catch (e) { console.warn("Failed to fetch payments", e); }

            if (state.currentView === 'dashboard') renderDashboard();
            if (state.currentView === 'vouchers') renderVouchers();
            if (state.currentView === 'users') renderUsers();
        } catch (e) {
            console.error("Data load error:", e);
        }
    }

    // Refresh resources every 1 second
    setInterval(() => {
        if (state.auth.isLoggedIn && state.mikrotik.status === 'online') {
            loadResourcesOnly();
        }
    }, 1000);

    async function loadResourcesOnly() {
        try {
            let resources, health, interfaces, identity;

            const results = await Promise.all([
                MikroTikAPI.getSystemResources(),
                MikroTikAPI.getSystemHealth(),
                MikroTikAPI.getInterfaces(),
                MikroTikAPI.getSystemIdentity()
            ]);
            resources = results[0][0] || results[0];
            health = results[1];
            interfaces = results[2];
            identity = results[3];

            state.mikrotik.resources = resources;
            state.mikrotik.health = health;
            state.mikrotik.interfaces = interfaces;
            state.mikrotik.identity = identity.name || identity[0]?.name || 'MikroTik';

            calculateSpeed(interfaces);

            // Fetch Real Sales - LIVE update every second
            try {
                const payments = await MikroTikAPI.getPayments();
                const now = new Date();
                const todayStr = now.toISOString().split('T')[0];
                let todaySales = 0;
                (payments || []).forEach(p => {
                    if (p.time && p.time.includes(todayStr)) {
                        todaySales += parseFloat(p.amount || 0);
                    } else if (p.time) {
                        const pDate = new Date(p.time.replace(/-/g, '/'));
                        if (pDate.toDateString() === now.toDateString()) {
                            todaySales += parseFloat(p.amount || 0);
                        }
                    }
                });
                state.sales.today = todaySales;
                state.payments = payments || [];
            } catch (e) { }

            const statusEl = document.querySelector('.router-status');
            if (statusEl && state.mikrotik.status === 'online') {
                statusEl.innerHTML = `${state.mikrotik.identity} ${t("router_online")}`;
                statusEl.style.background = "rgba(16, 185, 129, 0.15)";
                statusEl.style.color = "var(--success)";
            }

            if (state.currentView === 'dashboard') {
                updateDashboardDisplay();
            }
        } catch (e) { }
    }


    function calculateSpeed(interfaces) {
        if (!interfaces || !Array.isArray(interfaces)) return;

        const now = Date.now();
        let totalTx = 0, totalRx = 0;
        interfaces.forEach(iface => {
            totalTx += parseInt(iface['tx-byte'] || 0);
            totalRx += parseInt(iface['rx-byte'] || 0);
        });

        if (state.mikrotik.traffic.lastCheck > 0) {
            const diffSec = (now - state.mikrotik.traffic.lastCheck) / 1000;
            if (diffSec > 0) {
                state.mikrotik.traffic.txSpeed = Math.round(((totalTx - state.mikrotik.traffic.prevTx) * 8) / diffSec);
                state.mikrotik.traffic.rxSpeed = Math.round(((totalRx - state.mikrotik.traffic.prevRx) * 8) / diffSec);
            }
        }
        state.mikrotik.traffic.prevTx = totalTx;
        state.mikrotik.traffic.prevRx = totalRx;
        state.mikrotik.traffic.lastCheck = now;
    }

    function parseSizeToBytes(val) {
        if (!val) return 0;
        if (typeof val === 'number') return val;
        const str = String(val).trim();
        const match = str.match(/^([\d.]+)\s*([KMG]i?B|[KMG]B)?$/i);
        if (!match) {
            // agar faqat son bo'lsa (bayt deb olamiz)
            const num = parseFloat(str);
            return isNaN(num) ? 0 : num;
        }
        const num = parseFloat(match[1]);
        if (isNaN(num)) return 0;
        const unit = (match[2] || '').toUpperCase();
        switch (unit) {
            case 'KB':
            case 'KIB':
                return num * 1024;
            case 'MB':
            case 'MIB':
                return num * 1024 * 1024;
            case 'GB':
            case 'GIB':
                return num * 1024 * 1024 * 1024;
            default:
                return num;
        }
    }

    function formatBytesToGB(bytes) {
        if (!bytes || bytes <= 0) return '0 GB';
        const gb = bytes / (1024 * 1024 * 1024);
        return gb.toFixed(2) + ' GB';
    }

    function buildCSV(rows) {
        return rows.map(r => r.map(v => {
            const val = v == null ? '' : String(v);
            if (val.includes(',') || val.includes('"') || val.includes('\n')) {
                return `"${val.replace(/"/g, '""')}"`;
            }
            return val;
        }).join(',')).join('\n');
    }

    function downloadCSV(filename, rows) {
        const csv = buildCSV(rows);
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    }

    function formatSpeed(bps) {
        if (!bps || bps < 0) return "0 bps";
        if (bps > 1000000) return (bps / 1000000).toFixed(1) + " Mbps";
        if (bps > 1000) return (bps / 1000).toFixed(1) + " Kbps";
        return bps + " bps";
    }

    function updateDashboardStats() {
        const statsValues = document.querySelectorAll('.stat-value');
        if (statsValues.length >= 2) {
            statsValues[1].innerText = state.users.length; // Active/Total Users
        }
    }

    document.getElementById('logout-btn').addEventListener('click', () => {
        sessionStorage.removeItem('isLoggedIn');
        window.location.reload();
    });

    // Theme Toggle
    themeToggle.addEventListener('click', () => {
        state.theme = state.theme === 'light' ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', state.theme);
        localStorage.setItem('theme', state.theme);
    });

    // Modal Elements
    const modal = document.getElementById('modal');
    const modalTitle = document.getElementById('modal-title');
    const modalBody = document.getElementById('modal-body');
    const closeModalBtn = document.querySelector('.close-modal');

    function showModal(title, bodyHTML) {
        if (!modal) return;
        modalTitle.innerText = title;
        modalBody.innerHTML = bodyHTML;
        modal.style.display = 'block';
    }

    function hideModal() {
        if (!modal) return;
        modal.style.display = 'none';
        modalBody.innerHTML = '';
    }

    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', hideModal);
    }

    window.addEventListener('click', (e) => {
        if (e.target === modal) hideModal();
    });

    // Navigation Logic
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            if (item.id === 'logout-btn') return;
            e.preventDefault();
            const view = item.getAttribute('data-view');
            if (view) {
                switchView(view);

                // Close mobile menu if open
                if (window.innerWidth <= 900) {
                    sidebar.classList.remove('active');
                    if (sidebarOverlay) sidebarOverlay.classList.remove('active');
                }
            }
        });
    });

    function switchView(viewName) {
        state.currentView = viewName;

        // Update UI
        navItems.forEach(i => i.classList.remove('active'));
        const activeNav = document.querySelector(`[data-view="${viewName}"]`);
        if (activeNav) activeNav.classList.add('active');

        renderView(viewName);
    }

    function renderView(viewName) {
        switch (viewName) {
            case 'dashboard':
                renderDashboard();
                break;
            case 'users':
                renderUsers();
                break;
            case 'vouchers':
                renderVouchers();
                break;
            case 'sessions':
                renderSessions();
                break;
            case 'sales':
                renderSales();
                break;
            case 'settings':
                renderSettings();
                break;
            default:
                viewContainer.innerHTML = `<div class="user-card"><div class="card-header">Tez orada...</div></div>`;
        }
        renderContactFooter();
    }

    function renderContactFooter() {
        let footer = document.getElementById('contact-footer');
        if (!footer) {
            footer = document.createElement('div');
            footer.id = 'contact-footer';
            footer.style.cssText = `
                margin-top: 40px;
                padding: 18px 24px;
                background: linear-gradient(135deg, rgba(59,130,246,0.08), rgba(6,182,212,0.08));
                border: 1px solid rgba(99,179,237,0.25);
                border-radius: 16px;
                display: flex;
                align-items: center;
                justify-content: space-between;
                flex-wrap: wrap;
                gap: 12px;
            `;
            footer.innerHTML = `
                <div style="display:flex; align-items:center; gap:10px">
                    <span style="font-size:22px">📞</span>
                    <div>
                        <div style="font-size:12px; color:var(--text-muted); margin-bottom:2px">Aloqa uchun:</div>
                        <a href="tel:+998880220909" style="font-weight:700; color:var(--text-main); text-decoration:none; font-size:15px">+998 88 022 09 09</a>
                    </div>
                </div>
                <a href="https://t.me/raxmatillayev19" target="_blank" style="
                    display:flex; align-items:center; gap:8px;
                    background: linear-gradient(135deg, #229ED9, #1a7fc1);
                    color:white; text-decoration:none;
                    padding: 10px 18px; border-radius:12px;
                    font-weight:700; font-size:14px;
                    box-shadow: 0 4px 12px rgba(34,158,217,0.35);
                    transition: transform 0.2s;
                " onmouseover="this.style.transform='scale(1.04)'" onmouseout="this.style.transform='scale(1)'">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="white"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.833.941z"/></svg>
                    @raxmatillayev19
                </a>
            `;
            viewContainer.appendChild(footer);
        }
    }

    function renderDashboard() {
        if (state.currentView !== 'dashboard') return;

        // If already rendered, just update values
        if (document.getElementById('val-cpu-load')) {
            updateDashboardDisplay();
            return;
        }


        const res = state.mikrotik.resources || {};
        const health = state.mikrotik.health || [];
        const temp = health.find(h => h.name === 'temperature' || h.name === 'cpu-temperature')?.value || 'N/A';

        // Calculate RAM usage
        const totalRam = parseInt(res['total-memory'] || 0) / (1024 * 1024);
        const freeRam = parseInt(res['free-memory'] || 0) / (1024 * 1024);
        const usedRamPerc = totalRam > 0 ? Math.round(((totalRam - freeRam) / totalRam) * 100) : 0;

        // Calculate Disk usage
        const totalDisk = parseInt(res['total-hdd-space'] || 0) / (1024 * 1024);
        const freeDisk = parseInt(res['free-hdd-space'] || 0) / (1024 * 1024);
        const usedDiskPerc = totalDisk > 0 ? Math.round(((totalDisk - freeDisk) / totalDisk) * 100) : 0;

        viewContainer.innerHTML = `
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="card-header-flex">
                        <span class="stat-title">${t("dash_sold_today")}</span>
                    </div>
                    <div class="stat-value" id="val-sales">${state.sales.today.toLocaleString()} <span style="font-size: 16px; color: var(--text-muted)">UZS</span></div>
                    <div class="stat-desc" style="color: var(--success)" id="val-sales-growth">↑ ${state.sales.growth}% ${t("dash_growth")}</div>
                </div>
                <div class="stat-card">
                    <div class="card-header-flex">
                        <span class="stat-title">${t("dash_total_users")}</span>
                    </div>
                    <div class="stat-value">${state.users.length || 0}</div>
                    <div class="stat-desc">MikroTik RouterOS</div>
                </div>
                
                <div class="stat-card">
                    <div class="card-header-flex">
                        <span class="stat-title">${t("dash_cpu")}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: end">
                        <div class="stat-value" id="val-cpu-load">${res['cpu-load'] || 0}%</div>
                        <div class="stat-desc" style="text-align: right; padding-bottom: 5px" id="val-cpu-info">${res['cpu'] || 'CPU'}<br>${res['cpu-frequency'] || '?'}MHz</div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="card-header-flex">
                        <span class="stat-title">${t("dash_ram")}</span>
                    </div>
                    <div class="stat-value" id="val-ram-perc">${usedRamPerc}%</div>
                    <div class="usage-bar-container" style="height: 6px; margin-top: 10px">
                        <div class="usage-bar" id="bar-ram" style="width: ${usedRamPerc}%; background: ${usedRamPerc > 80 ? 'var(--danger)' : 'var(--accent-cyan)'}"></div>
                    </div>
                    <div class="stat-desc" style="margin-top: 5px" id="val-ram-info">${Math.round(totalRam - freeRam)}MB / ${Math.round(totalRam)}MB</div>
                </div>

                <div class="stat-card">
                    <div class="card-header-flex">
                        <span class="stat-title">${t("dash_storage")}</span>
                    </div>
                    <div class="stat-value" id="val-disk-perc">${usedDiskPerc}%</div>
                    <div class="usage-bar-container" style="height: 6px; margin-top: 10px">
                        <div class="usage-bar" id="bar-disk" style="width: ${usedDiskPerc}%; background: var(--accent-orange)"></div>
                    </div>
                    <div class="stat-desc" style="margin-top: 5px" id="val-disk-info">${Math.round(totalDisk - freeDisk)}MB / ${Math.round(totalDisk)}MB</div>
                </div>

                <div class="stat-card">
                    <div class="card-header-flex">
                        <span class="stat-title">${t("dash_uptime")}</span>
                    </div>
                    <div class="stat-value" id="val-uptime" style="font-size: 20px; white-space: nowrap">${res['uptime'] || '00:00:00'}</div>
                    <div class="stat-desc" style="margin-top: 5px" id="val-board">${res['board-name'] || 'MikroTik'} ${res['version'] ? 'v' + res['version'] : ''}</div>
                </div>

                <div class="stat-card">
                    <div class="card-header-flex">
                        <span class="stat-title">${t("dash_temp")}</span>
                    </div>
                    <div class="stat-value" id="val-temp" style="color: ${temp > 60 ? 'var(--danger)' : 'var(--text-main)'}">${temp}°C</div>
                    <div class="stat-desc">${t("dash_router_status")}: ${state.mikrotik.status}</div>
                </div>

                <div class="stat-card">
                    <div class="card-header-flex">
                        <span class="stat-title">${t("dash_speed")}</span>
                    </div>
                    <div>
                        <div class="stat-value" id="val-speed" style="font-size: 20px">🚀 ${formatSpeed(state.mikrotik.traffic.rxSpeed + state.mikrotik.traffic.txSpeed)}</div>
                        <div class="stat-desc" style="display: flex; gap: 15px; margin-top: 5px">
                            <span style="color: var(--success)" id="val-down">↓ ${formatSpeed(state.mikrotik.traffic.rxSpeed)}</span>
                            <span style="color: var(--accent-blue)" id="val-up">↑ ${formatSpeed(state.mikrotik.traffic.txSpeed)}</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="user-card" style="margin-top: 24px">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px">
                    <h3 style="font-size: 16px; font-weight: 800; letter-spacing: -0.2px">So'nggi 7 kun sotuvlari</h3>
                </div>
                <div id="sales-mini-chart" style="display: flex; gap: 8px; align-items: flex-end; height: 120px; margin-top: 8px"></div>
            </div>

            <div style="margin-top: 32px">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px">
                    <h3 style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px">${t("dash_quick_actions")}</h3>
                </div>
                <div class="user-cards-grid">
                    <div class="user-card" id="quick-voucher-btn" style="border-left: 6px solid var(--accent-orange); cursor: pointer; display: flex; align-items: center; justify-content: space-between">
                        <div>
                            <div class="username" style="color: var(--accent-orange)">${t("dash_create_voucher")}</div>
                            <p style="font-size: 14px; color: var(--text-muted); margin-top: 4px">${t("dash_create_voucher_desc")}</p>
                        </div>
                        <div style="font-size: 32px">➕</div>
                    </div>
                </div>
            </div>
        `;
        document.getElementById('quick-voucher-btn').addEventListener('click', openVoucherModal);
        renderSalesMiniChart();
    }

    function renderSalesMiniChart() {
        const container = document.getElementById('sales-mini-chart');
        if (!container) return;
        const payments = state.payments || [];
        if (!payments.length) {
            container.innerHTML = `<div style="font-size:13px;color:var(--text-muted)">Ma'lumotlar yo'q</div>`;
            return;
        }
        const map = {};
        payments.forEach(p => {
            if (!p.time) return;
            const d = new Date(p.time.replace(/-/g, '/'));
            const key = d.toISOString().split('T')[0];
            map[key] = (map[key] || 0) + parseFloat(p.amount || 0);
        });
        const days = Object.keys(map).sort().slice(-7);
        if (!days.length) {
            container.innerHTML = `<div style="font-size:13px;color:var(--text-muted)">Ma'lumotlar yo'q</div>`;
            return;
        }
        const max = Math.max(...days.map(d => map[d] || 0)) || 1;
        container.innerHTML = days.map(d => {
            const val = map[d] || 0;
            const h = Math.max(10, (val / max) * 100);
            const label = d.slice(5); // MM-DD
            return `
                <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px">
                    <div style="width:100%;background:linear-gradient(180deg,var(--accent-blue),var(--accent-cyan));border-radius:8px 8px 4px 4px;height:${h}px"></div>
                    <div style="font-size:11px;color:var(--text-muted)">${label}</div>
                </div>
            `;
        }).join('');
    }

    function updateDashboardDisplay() {
        const res = state.mikrotik.resources || {};
        const health = state.mikrotik.health || [];
        const temp = health.find(h => h.name === 'temperature' || h.name === 'cpu-temperature')?.value || 'N/A';

        const totalRam = parseInt(res['total-memory'] || 0) / (1024 * 1024);
        const freeRam = parseInt(res['free-memory'] || 0) / (1024 * 1024);
        const usedRamPerc = totalRam > 0 ? Math.round(((totalRam - freeRam) / totalRam) * 100) : 0;

        const totalDisk = parseInt(res['total-hdd-space'] || 0) / (1024 * 1024);
        const freeDisk = parseInt(res['free-hdd-space'] || 0) / (1024 * 1024);
        const usedDiskPerc = totalDisk > 0 ? Math.round(((totalDisk - freeDisk) / totalDisk) * 100) : 0;

        const updateEl = (id, val) => { const el = document.getElementById(id); if (el) el.innerHTML = val; };

        updateEl('val-cpu-load', `${res['cpu-load'] || 0}%`);
        updateEl('val-cpu-info', `${res['cpu'] || 'CPU'}<br>${res['cpu-frequency'] || '?'}MHz`);

        // Update Sales dynamically
        updateEl('val-sales', `${state.sales.today.toLocaleString()} <span style="font-size: 16px; color: var(--text-muted)">UZS</span>`);
        updateEl('val-sales-growth', `↑ ${state.sales.growth}% ${t("dash_growth")}`);

        updateEl('val-ram-perc', `${usedRamPerc}%`);
        const ramBar = document.getElementById('bar-ram');
        if (ramBar) {
            ramBar.style.width = `${usedRamPerc}%`;
            ramBar.style.background = usedRamPerc > 80 ? 'var(--danger)' : 'var(--accent-cyan)';
        }
        updateEl('val-ram-info', `${Math.round(totalRam - freeRam)}MB / ${Math.round(totalRam)}MB`);

        updateEl('val-disk-perc', `${usedDiskPerc}%`);
        const diskBar = document.getElementById('bar-disk');
        if (diskBar) diskBar.style.width = `${usedDiskPerc}%`;
        updateEl('val-disk-info', `${Math.round(totalDisk - freeDisk)}MB / ${Math.round(totalDisk)}MB`);

        updateEl('val-uptime', res['uptime'] || '00:00:00');
        updateEl('val-board', `${res['board-name'] || 'MikroTik'} ${res['version'] ? 'v' + res['version'] : ''}`);

        const tempEl = document.getElementById('val-temp');
        if (tempEl) {
            tempEl.innerHTML = `${temp}°C`;
            tempEl.style.color = temp > 60 ? 'var(--danger)' : 'var(--text-main)';
        }

        updateEl('val-speed', `🚀 ${formatSpeed(state.mikrotik.traffic.rxSpeed + state.mikrotik.traffic.txSpeed)}`);
        updateEl('val-down', `↓ ${formatSpeed(state.mikrotik.traffic.rxSpeed)}`);
        updateEl('val-up', `↑ ${formatSpeed(state.mikrotik.traffic.txSpeed)}`);
    }

    function renderUsers() {
        // Umumiy trafikni hisoblash (download + upload)
        let totalBytes = 0;
        const usersWithUsage = (state.users || []).map(user => {
            const downBytes = parseSizeToBytes(user['download-used']);
            const upBytes = parseSizeToBytes(user['upload-used']);
            const totalUserBytes = downBytes + upBytes;
            totalBytes += totalUserBytes;
            return {
                raw: user,
                downHuman: user['download-used'] || '0',
                upHuman: user['upload-used'] || '0',
                totalHuman: formatBytesToGB(totalUserBytes)
            };
        });

        viewContainer.innerHTML = `
            <div style="margin-bottom: 32px">
                <h2 style="font-size: 28px; font-weight: 900; letter-spacing: -1px">${t("users_title")}</h2>
                <p style="margin-top: 8px; font-size: 13px; color: var(--text-muted)">
                    Jami ishlatilgan trafik: <span style="font-weight: 700; color: var(--accent-blue)">${formatBytesToGB(totalBytes)}</span>
                </p>
                <button id="export-users-csv" class="btn btn-outline" style="margin-top: 10px; width: 220px">
                    CSV eksport (mijozlar)
                </button>
            </div>
            
            <div class="user-cards-grid">
                <!-- Add New User Card -->
                <div class="user-card" id="card-add-user" style="border: 2px dashed var(--accent-blue); background: rgba(59, 130, 246, 0.05); display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 200px; cursor: pointer; transition: all 0.3s ease;">
                    <div style="font-size: 48px; margin-bottom: 12px">👤</div>
                    <div style="font-weight: 800; font-size: 18px; color: var(--accent-blue)">${t("users_new_card")}</div>
                    <p style="font-size: 13px; color: var(--text-muted); margin-top: 8px">${t("users_new_desc")}</p>
                </div>

                ${usersWithUsage.length === 0 ? '' :
                usersWithUsage.map(u => `
                    <div class="user-card">
                        <div class="user-card-header">
                            <span class="username">${u.raw.name || u.raw.username}</span>
                            <span class="badge ${u.raw.disabled === 'true' ? 'badge-expired' : 'badge-active'}">
                                ${u.raw.disabled === 'true' ? 'Offline' : 'Online'}
                            </span>
                        </div>
                        <div class="usage-info">
                            <div class="usage-label">
                                <span>Download / Upload / Jami</span>
                                <span>${u.downHuman} / ${u.upHuman} / ${u.totalHuman}</span>
                            </div>
                            <div class="usage-bar-container"><div class="usage-bar" style="width: 45%"></div></div>
                        </div>
                        <div class="user-actions">
                            <button class="btn btn-outline" onclick="deleteUser('${u.raw.name || u.raw.username}')" style="color: var(--danger)">${t("btn_delete")}</button>
                            <button class="btn btn-outline" onclick="alert('${t("btn_edit")} tez orada...')">${t("btn_edit")}</button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
        document.getElementById('card-add-user').addEventListener('click', openUserModal);

        document.getElementById('export-users-csv').addEventListener('click', () => {
            const rows = [
                ['Login', 'Holati', 'Download', 'Upload', 'Jami GB']
            ];
            usersWithUsage.forEach(u => {
                rows.push([
                    u.raw.name || u.raw.username || '',
                    u.raw.disabled === 'true' ? 'Offline' : 'Online',
                    u.downHuman,
                    u.upHuman,
                    u.totalHuman
                ]);
            });
            downloadCSV('users.csv', rows);
        });
    }

    function renderVouchers() {
        viewContainer.innerHTML = `
            <div style="margin-bottom: 32px">
                <h2 style="font-size: 28px; font-weight: 900; letter-spacing: -1px">${t("vouchers_title")}</h2>
                <div style="margin-top: 8px; display:flex; gap:8px; flex-wrap:wrap">
                    <button id="print-all-vouchers" class="btn btn-outline" style="max-width:220px">${t("btn_print")} (barchasi)</button>
                </div>
            </div>
            
            <div class="user-cards-grid">
                <!-- Add New Voucher Card -->
                <div class="user-card" id="card-add-vouchers" style="border: 2px dashed var(--accent-blue); background: rgba(59, 130, 246, 0.05); display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 200px; cursor: pointer; transition: all 0.3s ease;">
                    <div style="font-size: 48px; margin-bottom: 12px">📥</div>
                    <div style="font-weight: 800; font-size: 18px; color: var(--accent-blue)">${t("vouchers_create_card")}</div>
                    <p style="font-size: 13px; color: var(--text-muted); margin-top: 8px">${t("vouchers_create_desc")}</p>
                </div>

                ${state.vouchers.length === 0 ? '' :
                state.vouchers.map(v => `
                    <div class="user-card" style="border-top: 4px solid var(--accent-cyan)">
                        <div class="user-card-header">
                            <span class="username" style="font-family: monospace">${v.name}</span>
                            <span class="badge" style="background: #E2E8F0">${v.price || 'vaucher'}</span>
                        </div>
                        <div style="font-size: 13px; color: var(--text-muted); line-height: 1.6">
                            <div>Profil: ${v.profile || 'vaucher'}</div>
                        </div>
                        <div class="user-actions" style="margin-top: 12px">
                            <button class="btn btn-outline" onclick="printVoucher('${v.name}')">${t("btn_print")}</button>
                            <button class="btn btn-outline" onclick="deleteUser('${v.name}')" style="color: var(--danger)">${t("btn_delete")}</button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
        document.getElementById('card-add-vouchers').addEventListener('click', openVoucherModal);

        const printAllBtn = document.getElementById('print-all-vouchers');
        if (printAllBtn) {
            printAllBtn.addEventListener('click', () => {
                if (!state.vouchers.length) {
                    alert("Vaucherlar yo'q");
                    return;
                }
                const w = window.open('', '_blank');
                w.document.write(`
                    <html><head>
                        <title>Vouchers</title>
                        <style>
                            body { font-family: 'Inter', sans-serif; margin: 0; padding: 20px; }
                            .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 16px; }
                            .card { border: 1px dashed #000; border-radius: 10px; padding: 10px; text-align: center; }
                            .code { font-size: 16px; font-weight: 700; font-family: monospace; margin-top: 6px; }
                            .qr { width: 100px; height: 100px; margin: 0 auto; }
                            @media print { .no-print { display:none; } }
                        </style>
                    </head><body>
                        <div class="grid">
                            ${state.vouchers.map(v => {
                    const id = v.name;
                    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${id}`;
                    return `
                                    <div class="card">
                                        <img class="qr" src="${qrUrl}" />
                                        <div class="code">${id}</div>
                                    </div>
                                `;
                }).join('')}
                        </div>
                        <div class="no-print" style="margin-top:20px;text-align:center">
                            <button onclick="window.print()">Print</button>
                        </div>
                    </body></html>
                `);
                w.document.close();
            });
        }
    }

    function renderSales() {
        const payments = state.payments || [];
        viewContainer.innerHTML = `
            <div style="margin-bottom: 24px">
                <h2 style="font-size: 24px; font-weight: 800">💵 Sotuvlar tarixi</h2>
                <div style="margin-top: 8px; display:flex; gap:8px; flex-wrap:wrap">
                    <button id="export-sales-csv" class="btn btn-outline" style="max-width:200px">CSV eksport</button>
                    <button id="print-sales" class="btn btn-outline" style="max-width:200px">Print / PDF</button>
                </div>
            </div>
            <div class="user-card">
                <table style="width: 100%; border-collapse: collapse; font-size: 14px">
                    <thead>
                        <tr style="text-align: left; border-bottom: 1px solid var(--border-light)">
                            <th style="padding: 12px">Sana / Vaqt</th>
                            <th style="padding: 12px">Foydalanuvchi</th>
                            <th style="padding: 12px">Summa</th>
                            <th style="padding: 12px">Izoh / Turi</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${!payments.length
                ? `<tr><td colspan="4" style="padding: 20px; text-align: center; color: var(--text-muted)">Ma'lumotlar yo'q</td></tr>`
                : payments.map(p => {
                    const time = p.time || p.date || '';
                    const user = p.user || p.customer || p['user'] || '-';
                    const amount = p.amount != null ? Number(p.amount).toLocaleString() + ' UZS' : '-';
                    const note = p.comment || p.type || '';
                    return `
                                        <tr style="border-bottom: 1px solid rgba(226,232,240,0.5)">
                                            <td style="padding: 10px 12px; white-space: nowrap">${time}</td>
                                            <td style="padding: 10px 12px">${user}</td>
                                            <td style="padding: 10px 12px; font-weight: 600">${amount}</td>
                                            <td style="padding: 10px 12px; color: var(--text-muted)">${note}</td>
                                        </tr>
                                    `;
                }).join('')
            }
                    </tbody>
                </table>
            </div>
        `;

        const rows = [['Sana/Vaqt', 'Foydalanuvchi', 'Summa', 'Izoh/Turi']];
        payments.forEach(p => {
            const time = p.time || p.date || '';
            const user = p.user || p.customer || p['user'] || '-';
            const amount = p.amount != null ? Number(p.amount) : 0;
            const note = p.comment || p.type || '';
            rows.push([time, user, String(amount), note]);
        });

        document.getElementById('export-sales-csv').addEventListener('click', () => {
            downloadCSV('sales.csv', rows);
        });

        document.getElementById('print-sales').addEventListener('click', () => {
            const w = window.open('', '_blank');
            w.document.write(`
                <html><head>
                    <title>Sotuvlar</title>
                    <style>
                        body { font-family: 'Inter', sans-serif; padding: 20px; }
                        table { width: 100%; border-collapse: collapse; font-size: 12px; }
                        th, td { border: 1px solid #cbd5e1; padding: 6px 8px; text-align: left; }
                        th { background:#e2e8f0; }
                    </style>
                </head><body>
                    <h3>💵 Sotuvlar tarixi</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Sana / Vaqt</th>
                                <th>Foydalanuvchi</th>
                                <th>Summa</th>
                                <th>Izoh / Turi</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${payments.map(p => {
                const time = p.time || p.date || '';
                const user = p.user || p.customer || p['user'] || '-';
                const amount = p.amount != null ? Number(p.amount).toLocaleString() + ' UZS' : '-';
                const note = p.comment || p.type || '';
                return `
                                    <tr>
                                        <td>${time}</td>
                                        <td>${user}</td>
                                        <td>${amount}</td>
                                        <td>${note}</td>
                                    </tr>
                                `;
            }).join('')}
                        </tbody>
                    </table>
                    <script>window.print();<\/script>
                </body></html>
            `);
            w.document.close();
        });
    }

    function renderSessions() {
        const sessions = state.sessions || [];
        viewContainer.innerHTML = `
            <div style="margin-bottom: 24px">
                <h2 style="font-size: 24px; font-weight: 800">📶 Foydalanuvchi sessiyalari</h2>
            </div>
            <div class="user-card">
                <table style="width: 100%; border-collapse: collapse; font-size: 14px">
                    <thead>
                        <tr style="text-align: left; border-bottom: 1px solid var(--border-light)">
                            <th style="padding: 12px">Login</th>
                            <th style="padding: 12px">IP / MAC</th>
                            <th style="padding: 12px">Uptime</th>
                            <th style="padding: 12px">Download</th>
                            <th style="padding: 12px">Upload</th>
                            <th style="padding: 12px">Amal</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${!sessions.length
                ? `<tr><td colspan="6" style="padding: 20px; text-align: center; color: var(--text-muted)">Aktiv sessiyalar topilmadi</td></tr>`
                : sessions.map(s => {
                    const user = s.user || s.name || '-';
                    const addr = s.address || s['calling-station-id'] || s['mac-address'] || '-';
                    const uptime = s.uptime || s['session-time-left'] || '-';
                    const download = s['download'] || s['download-used'] || '-';
                    const upload = s['upload'] || s['upload-used'] || '-';
                    const id = s['.id'] || '';
                    return `
                                        <tr style="border-bottom: 1px solid rgba(226,232,240,0.5)">
                                            <td style="padding: 10px 12px">${user}</td>
                                            <td style="padding: 10px 12px">${addr}</td>
                                            <td style="padding: 10px 12px">${uptime}</td>
                                            <td style="padding: 10px 12px">${download}</td>
                                            <td style="padding: 10px 12px">${upload}</td>
                                            <td style="padding: 10px 12px">
                                                ${id ? `<button class="btn btn-outline" onclick="endSession('${id}')" style="padding:6px 10px; font-size:12px; color: var(--danger)">Disconnect</button>` : ''}
                                            </td>
                                        </tr>
                                    `;
                }).join('')
            }
                    </tbody>
                </table>
            </div>
        `;
    }

    function renderSettings() {
        const savedServerIp = localStorage.getItem('server_ip') || '';
        viewContainer.innerHTML = `
            <div class="user-cards-grid">

                <!-- Server IP Panel (Mobil kirish uchun) -->
                <div class="user-card" style="border-left: 5px solid var(--accent-cyan); grid-column: 1 / -1">
                    <h3 style="margin-bottom: 6px; font-weight: 800">🌐 Server IP Manzili <span style="font-size:12px;font-weight:400;color:var(--text-muted)">(Telefondan kirish uchun)</span></h3>
                    <p style="font-size:13px; color:var(--text-muted); margin-bottom:16px">
                        Kompyuterdan ochsangiz bo'sh qoldiring. Telefondan kirish uchun kompyuterning lokal IP manzilini kiriting (masatan: <b>192.168.1.5</b>).
                    </p>
                    <div style="display:flex; gap:12px; flex-wrap:wrap; align-items:center">
                        <div class="form-group" style="flex:1; min-width:220px; margin-bottom:0">
                            <label>Kompyuter IP manzili</label>
                            <input type="text" id="set-server-ip" value="${savedServerIp}" placeholder="Masalan: 192.168.1.5 (bo'sh = localhost)">
                        </div>
                        <button id="btn-save-server-ip" class="btn btn-primary" style="margin-top:22px; white-space:nowrap">💾 Saqlash</button>
                        <button id="btn-clear-server-ip" class="btn btn-outline" style="margin-top:22px; color:var(--danger); white-space:nowrap">🗑️ Tozalash</button>
                    </div>
                    <div id="server-ip-status" style="margin-top:10px; font-size:13px; display:none"></div>
                    <div style="margin-top:14px; padding:12px; background:rgba(6,182,212,0.08); border-radius:10px; font-size:13px; color:var(--text-muted)">
                        💡 <b>Qo'llanma:</b> Kompyuterning IP manzilini bilish uchun: <code style="background:rgba(0,0,0,0.08);padding:2px 6px;border-radius:6px">ipconfig</code> buyrug'ini ishlating → <b>IPv4 Address</b> ni ko'ring.
                        Saytga telefonda kirish: <code style="background:rgba(0,0,0,0.08);padding:2px 6px;border-radius:6px">http://[IP]:8000</code>
                    </div>
                </div>
                
                <!-- Ping Console Panel -->
                <div class="user-card" style="border-left: 5px solid var(--accent-orange); grid-column: 1 / -1">
                    <h3 style="margin-bottom: 6px; font-weight: 800">📟 MikroTik Ping Konsoli</h3>
                    <p style="font-size:13px; color:var(--text-muted); margin-bottom:16px">
                        Routerdan biror manzilga (masalan: 8.8.8.8) ping berib ko'rish.
                    </p>
                    <div style="display:flex; gap:12px; flex-wrap:wrap; align-items:center; margin-bottom: 12px">
                        <div class="form-group" style="flex:1; min-width:220px; margin-bottom:0">
                            <input type="text" id="ping-address" value="8.8.8.8" placeholder="IP yoki Host">
                        </div>
                        <button id="btn-run-ping" class="btn btn-primary" style="white-space:nowrap; background: var(--accent-orange)">📡 Ping Berish</button>
                    </div>
                    <div id="ping-console" style="
                        background: #1a1a1a; 
                        color: #00ff00; 
                        padding: 15px; 
                        border-radius: 10px; 
                        font-family: 'Courier New', Courier, monospace; 
                        font-size: 13px; 
                        height: 150px; 
                        overflow-y: auto;
                        border: 1px solid #333;
                    ">
                        <div style="color: #666"># Ping natijalari bu yerda chiqadi...</div>
                    </div>
                </div>

                <div class="user-card">
                    <h3 style="margin-bottom: 24px; font-weight: 800">${t("settings_admin")}</h3>
                    <form id="settings-admin-form">
                        <div class="form-group">
                            <label>Login</label>
                            <input type="text" id="set-admin-user" value="${state.auth.username}" required>
                        </div>
                        <div class="form-group">
                            <label>${t("password")}</label>
                            <input type="password" id="set-admin-pass" value="${state.auth.password}" required>
                        </div>
                        <div class="form-group">
                            <label>Role</label>
                            <select id="set-admin-role">
                                <option value="admin" ${state.auth.role === 'admin' ? 'selected' : ''}>Admin (to'liq huquq)</option>
                                <option value="seller" ${state.auth.role === 'seller' ? 'selected' : ''}>Seller (faqat sotuv)</option>
                                <option value="viewer" ${state.auth.role === 'viewer' ? 'selected' : ''}>Viewer (faqat ko'rish)</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary" style="width: 100%">${t("settings_change")}</button>
                    </form>
                    <div id="settings-admin-success" style="margin-top: 15px; color: var(--success); font-weight: 600; text-align: center; display: none;">
                        ✅ ${t("settings_success")}
                    </div>
                </div>

                <div class="user-card">
                    <h3 style="margin-bottom: 24px; font-weight: 800">${t("settings_router")}</h3>
                    <form id="settings-router-form">
                        <div class="form-group">
                            <label>Router IP / Host</label>
                            <input type="text" id="set-mk-host" value="${state.mikrotik.host}" placeholder="192.168.88.1" required>
                        </div>
                        <div class="form-group">
                            <label>API User</label>
                            <input type="text" id="set-mk-user" value="${state.mikrotik.user}" required>
                        </div>
                        <div class="form-group">
                            <label>API Password</label>
                            <input type="password" id="set-mk-pass" value="${state.mikrotik.pass}" required>
                        </div>
                        <div class="form-group">
                            <label>Router nomi</label>
                            <input type="text" id="set-mk-name" value="${state.currentRouterName}" placeholder="Masalan: Ofis-hAP" >
                        </div>
                        <button type="submit" class="btn btn-primary" style="width: 100%">💾 Saqlash va Ulash</button>
                    </form>
                    <div id="settings-router-success" style="margin-top: 15px; color: var(--success); font-weight: 600; text-align: center; display: none;">
                        ✅ ${t("settings_success")}
                    </div>
                    <div style="margin-top:16px">
                        <label style="font-size:12px;color:var(--text-muted);display:block;margin-bottom:6px">Saqlangan routerlar</label>
                        <select id="router-list" style="width:100%;padding:10px;border-radius:10px;border:1px solid var(--border-light)">
                            <option value="">(Tanlanmagan)</option>
                            ${state.routers.map(r => `
                                <option value="${r.name}" ${r.name === state.currentRouterName ? 'selected' : ''}>${r.name} - ${r.host}</option>
                            `).join('')}
                        </select>
                        <button id="save-router-profile" class="btn btn-outline" style="width: 100%; margin-top: 8px">Profil sifatida saqlash</button>
                    </div>
                </div>

                </div>
            </div>
        `;


        document.getElementById('settings-router-form').addEventListener('submit', (e) => {
            e.preventDefault();
            const host = document.getElementById('set-mk-host').value;
            const user = document.getElementById('set-mk-user').value;
            const pass = document.getElementById('set-mk-pass').value;
            const name = document.getElementById('set-mk-name').value || host;

            state.mikrotik.host = host;
            state.mikrotik.user = user;
            state.mikrotik.pass = pass;
            state.currentRouterName = name;

            MikroTikAPI.saveConfig(host, user, pass);

            // update routers list
            const existingIdx = state.routers.findIndex(r => r.name === name);
            const profile = { name, host, user };
            if (existingIdx >= 0) {
                state.routers[existingIdx] = profile;
            } else {
                state.routers.push(profile);
            }
            localStorage.setItem('mk_routers', JSON.stringify(state.routers));
            localStorage.setItem('mk_router_active', name);
            testMikroTikConnection();

            document.getElementById('settings-router-success').style.display = 'block';
            setTimeout(() => { document.getElementById('settings-router-success').style.display = 'none'; }, 3000);
        });

        document.getElementById('settings-admin-form').addEventListener('submit', (e) => {
            e.preventDefault();
            const u = document.getElementById('set-admin-user').value;
            const p = document.getElementById('set-admin-pass').value;
            const r = document.getElementById('set-admin-role').value;

            state.auth.username = u;
            state.auth.password = p;
            state.auth.role = r;
            localStorage.setItem('admin_user', u);
            localStorage.setItem('admin_pass', p);
            localStorage.setItem('admin_role', r);

            document.getElementById('settings-admin-success').style.display = 'block';
            setTimeout(() => { document.getElementById('settings-admin-success').style.display = 'none'; }, 3000);
            applyRoleRestrictions();
        });

        const routerList = document.getElementById('router-list');
        const saveProfileBtn = document.getElementById('save-router-profile');

        if (routerList) {
            routerList.addEventListener('change', (e) => {
                const name = e.target.value;
                if (!name) return;
                const prof = state.routers.find(r => r.name === name);
                if (!prof) return;
                state.currentRouterName = prof.name;
                state.mikrotik.host = prof.host;
                state.mikrotik.user = prof.user;
                document.getElementById('set-mk-name').value = prof.name;
                document.getElementById('set-mk-host').value = prof.host;
                document.getElementById('set-mk-user').value = prof.user;
                localStorage.setItem('mk_router_active', prof.name);
                MikroTikAPI.saveConfig(prof.host, prof.user, state.mikrotik.pass);
                testMikroTikConnection();
            });
        }

        if (saveProfileBtn) {
            saveProfileBtn.addEventListener('click', () => {
                const host = document.getElementById('set-mk-host').value;
                const user = document.getElementById('set-mk-user').value;
                const name = document.getElementById('set-mk-name').value || host;
                const existingIdx = state.routers.findIndex(r => r.name === name);
                const profile = { name, host, user };
                if (existingIdx >= 0) {
                    state.routers[existingIdx] = profile;
                } else {
                    state.routers.push(profile);
                }
                state.currentRouterName = name;
                localStorage.setItem('mk_routers', JSON.stringify(state.routers));
                localStorage.setItem('mk_router_active', name);
                alert("Router profili saqlandi");
                renderSettings();
            });
        }

        // Server IP save/clear buttons
        const btnSaveIp = document.getElementById('btn-save-server-ip');
        const btnClearIp = document.getElementById('btn-clear-server-ip');
        const ipStatus = document.getElementById('server-ip-status');

        if (btnSaveIp) {
            btnSaveIp.addEventListener('click', () => {
                const ip = document.getElementById('set-server-ip').value.trim();
                localStorage.setItem('server_ip', ip);
                ipStatus.style.display = 'block';
                ipStatus.style.color = 'var(--success)';
                ipStatus.innerHTML = ip
                    ? `✅ Saqlandi! Endi <b>http://${ip}</b> orqali kirishingiz mumkin.`
                    : '✅ Tozalandi. Domendagi joriy manzildan foydalaniladi.';
                setTimeout(() => { ipStatus.style.display = 'none'; }, 4000);
            });
        }

        if (btnClearIp) {
            btnClearIp.addEventListener('click', () => {
                localStorage.removeItem('server_ip');
                document.getElementById('set-server-ip').value = '';
                ipStatus.style.display = 'block';
                ipStatus.style.color = 'var(--text-muted)';
                ipStatus.innerHTML = '🗑️ IP manzil tozalandi. Localhost rejimida ishlaydi.';
                setTimeout(() => { ipStatus.style.display = 'none'; }, 3000);
            });
        }

        // Ping Console logic
        const btnRunPing = document.getElementById('btn-run-ping');
        const pingConsole = document.getElementById('ping-console');
        const pingAddrInput = document.getElementById('ping-address');

        if (btnRunPing) {
            btnRunPing.addEventListener('click', async () => {
                const address = pingAddrInput.value.trim();
                if (!address) return;

                btnRunPing.disabled = true;
                pingConsole.innerHTML = `<div style="color: #aaa"># Pinging ${address}...</div>`;

                try {
                    const results = await MikroTikAPI.ping(address);
                    pingConsole.innerHTML = "";

                    if (Array.isArray(results)) {
                        results.forEach(res => {
                            const line = document.createElement('div');
                            if (res.status === "timeout") {
                                line.style.color = "var(--danger)";
                                line.innerText = `Request timeout for ${res.host || address}`;
                            } else {
                                line.innerText = `Reply from ${res.host || address}: bytes=${res['sent-size'] || 32} time=${res.time}ms ${res.ttl ? 'TTL=' + res.ttl : ''}`;
                            }
                            pingConsole.appendChild(line);
                        });
                        pingConsole.innerHTML += `<div style="color: #00ff00; margin-top:5px"># Ping tugadi.</div>`;
                    } else {
                        pingConsole.innerHTML = `<div style="color: var(--danger)">Xatolik: Natija kutilgan formatda emas.</div>`;
                    }
                } catch (err) {
                    pingConsole.innerHTML = `<div style="color: var(--danger)">Xatolik: ${err.message}</div>`;
                } finally {
                    btnRunPing.disabled = false;
                    pingConsole.scrollTop = pingConsole.scrollHeight;
                }
            });
        }
    }
});

// Delete User Function
window.deleteUser = async function (name) {
    if (!confirm(`${name} ${t("confirm_delete")}`)) return;
    try {
        await MikroTikAPI.deleteUser(name);
        loadData();
    } catch (err) {
        alert("O'chirishda xatolik: " + err.message);
    }
};

// End Session Function
window.endSession = async function (id) {
    if (!id) return;
    if (!confirm("Ushbu sessiyani uzib tashlamoqchimisiz?")) return;
    try {
        await MikroTikAPI.deleteSession(id);
        loadData();
    } catch (err) {
        alert("Sessiyani tugatishda xatolik: " + err.message);
    }
};

// Print Voucher Function
window.printVoucher = function (id) {
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${id}`;
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
            <html>
            <head>
                <title>Voucher - ${id}</title>
                <style>
                    body { font-family: 'Inter', sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background: white; }
                    .voucher-print { width: 300px; padding: 20px; border: 2px dashed #000; border-radius: 12px; text-align: center; }
                    .qr-code { width: 150px; height: 150px; margin: 15px auto; border: 1px solid #000; padding: 5px; }
                    .code { font-size: 20px; font-weight: 700; font-family: monospace; letter-spacing: 2px; }
                    @media print { .no-print { display: none; } }
                </style>
            </head>
            <body>
                <div class="voucher-print">
                    <img class="qr-code" src="${qrUrl}" alt="QR">
                    <div class="code">${id}</div>
                    <button class="no-print" onclick="window.print()">Chop etish</button>
                </div>
            </body>
            </html>
        `);
    printWindow.document.close();
};

async function openVoucherModal() {
    if (state.mikrotik.status !== 'online') {
        alert(t("modal_add_voucher") + " uchun avval MikroTikga ulaning!");
        return;
    }

    const profilesHTML = state.profiles.map(p => `<option value="${p.name}">${p.name}</option>`).join('');

    const formHTML = `
            <form id="v-form">
                <div class="form-group">
                    <label>${t("form_profile")}</label>
                    <select id="v-profile" required>
                        ${profilesHTML || '<option disabled>Profil topilmadi</option>'}
                    </select>
                </div>
                <div class="form-group">
                    <label>${t("form_prefix")}</label>
                    <input type="text" id="v-prefix" value="MH-" placeholder="Masalan: MH-" required>
                </div>
                <div class="form-group">
                    <label>${t("form_price")}</label>
                    <input type="number" id="v-price" value="10000" step="500" required>
                </div>
                <div class="form-group">
                    <label>${t("form_count")}</label>
                    <input type="number" id="v-count" value="5" min="1" max="50" required>
                </div>
                <div id="v-status" style="font-size: 13px; color: var(--accent-blue); margin-bottom: 10px; display: none;">${t("form_creating")}</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline" id="v-cancel">${t("form_cancel")}</button>
                    <button type="submit" class="btn btn-primary" id="v-submit">${t("form_generate")}</button>
                </div>
            </form>
        `;
    showModal(t("modal_add_voucher"), formHTML);

    document.getElementById('v-cancel').addEventListener('click', hideModal);
    document.getElementById('v-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const profile = document.getElementById('v-profile').value;
        const prefix = document.getElementById('v-prefix').value;
        const price = document.getElementById('v-price').value;
        const count = parseInt(document.getElementById('v-count').value);
        const statusEl = document.getElementById('v-status');
        const submitBtn = document.getElementById('v-submit');

        statusEl.style.display = 'block';
        submitBtn.disabled = true;

        try {
            for (let i = 0; i < count; i++) {
                const randomId = Math.random().toString(36).substr(2, 4).toUpperCase();
                const name = `${prefix}${randomId}`;
                statusEl.innerText = `${i + 1}/${count} ${t("form_creating")}: ${name}`;

                await MikroTikAPI.createUser({
                    name: name,
                    profile: profile,
                    comment: 'MikroTik-Voucher',
                    attributes: `price=${price}`
                });
            }
            hideModal();
            loadData();
            switchView('vouchers');
        } catch (err) {
            alert("Xatolik: " + err.message);
            statusEl.style.display = 'none';
            submitBtn.disabled = false;
        }
    });
}

function openUserModal() {
    if (state.mikrotik.status !== 'online') {
        alert(t("modal_add_user") + " uchun MikroTikga ulaning!");
        return;
    }

    const profilesHTML = state.profiles.map(p => `<option value="${p.name}">${p.name}</option>`).join('');

    const formHTML = `
            <form id="u-form">
                <div class="form-group">
                    <label>${t("form_login_label")}</label>
                    <input type="text" id="u-name" placeholder="Masalan: ali_88" required>
                </div>
                <div class="form-group">
                    <label>${t("form_pass_label")}</label>
                    <input type="password" id="u-pass" placeholder="Bo'sh qoldirilsa parolsiz bo'ladi">
                </div>
                <div class="form-group">
                    <label>${t("form_profile")}</label>
                    <select id="u-profile" required>
                        ${profilesHTML || '<option disabled>Profil topilmadi</option>'}
                    </select>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline" id="u-cancel">${t("form_cancel")}</button>
                    <button type="submit" class="btn btn-primary">${t("form_add")}</button>
                </div>
            </form>
        `;
    showModal(t("modal_add_user"), formHTML);

    document.getElementById('u-cancel').addEventListener('click', hideModal);
    document.getElementById('u-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = document.getElementById('u-name').value;
        const password = document.getElementById('u-pass').value;
        const profile = document.getElementById('u-profile').value;

        try {
            await MikroTikAPI.createUser({
                name,
                password,
                profile,
                comment: 'MikroTik-User'
            });
            hideModal();
            loadData();
            switchView('users');
        } catch (err) {
            alert("Xatolik: " + err.message);
        }
    });
}

    // Eski fallback renderSales funksiyasi olib tashlandi – yuqoridagi to'liq jadval ishlatiladi
});
