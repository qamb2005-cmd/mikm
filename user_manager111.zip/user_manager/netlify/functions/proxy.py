import json
import urllib.request
import urllib.error
import ssl
import os

def handler(event, context):
    path = event.get('path', '')
    http_method = event.get('httpMethod', 'GET')
    
    # Environment Variables from Netlify Dashboard
    ADMIN_USER = os.environ.get('ADMIN_USER', 'Mashhurbek')
    ADMIN_PASS = os.environ.get('ADMIN_PASS', 'Mashhurbek_2006@')

    # Security Headers for all responses
    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'X-Target-URL, Authorization, Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
    }

    # Handle Login Request
    if '/api/login' in path:
        if http_method != 'POST':
            return {'statusCode': 405, 'headers': headers, 'body': json.dumps({'error': 'Method not allowed'})}
        
        try:
            body = json.loads(event.get('body', '{}'))
            u = body.get('username', '')
            p = body.get('password', '')
            
            if u.lower() == ADMIN_USER.lower() and p == ADMIN_PASS:
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps({'status': 'success', 'message': 'Authenticated'})
                }
            else:
                return {
                    'statusCode': 401,
                    'headers': headers,
                    'body': json.dumps({'status': 'error', 'message': 'Invalid credentials'})
                }
        except Exception as e:
            return {'statusCode': 400, 'headers': headers, 'body': json.dumps({'error': str(e)})}

    # Handle Proxy Request (CORS Bypass)
    if '/api-proxy' in path:
        if http_method == 'OPTIONS':
            return {'statusCode': 200, 'headers': headers, 'body': ''}
            
        if http_method != 'POST':
            return {'statusCode': 405, 'headers': headers, 'body': json.dumps({'error': 'Method not allowed'})}

        req_headers = event.get('headers', {})
        target_url = req_headers.get('x-target-url') or req_headers.get('X-Target-URL')
        auth_header = req_headers.get('authorization') or req_headers.get('Authorization')

        if not target_url:
            return {'statusCode': 400, 'headers': headers, 'body': json.dumps({'error': 'Missing X-Target-URL header'})}

        body = event.get('body')
        if event.get('isBase64Encoded'):
            import base64
            body = base64.b64decode(body)
        
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

            req = urllib.request.Request(target_url, data=body.encode() if isinstance(body, str) else body, method='POST')
            if auth_header:
                req.add_header('Authorization', auth_header)
            req.add_header('Content-Type', 'application/json')

            with urllib.request.urlopen(req, context=ctx) as response:
                res_body = response.read().decode('utf-8')
                return {
                    'statusCode': response.status,
                    'headers': headers,
                    'body': res_body
                }

        except urllib.error.HTTPError as e:
            return {'statusCode': e.code, 'headers': headers, 'body': e.read().decode('utf-8')}
        except Exception as e:
            return {'statusCode': 500, 'headers': headers, 'body': json.dumps({'error': str(e)})}

    return {
        'statusCode': 404,
        'headers': headers,
        'body': json.dumps({'error': 'Not found'})
    }
